/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app_datapengunjung;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author LAB
 */
public class data_pengunjung extends javax.swing.JFrame {
    private DefaultTableModel ttable1;
    
    public data_pengunjung() {
        initComponents();
        HitungBiayaDewasa();
        HitungBiayaAnak();
        TampilAllData();
        TampilWaktu();
    }
    
    private void TampilWaktu(){
        ActionListener taskPerformer = new ActionListener() {

        @Override
            public void actionPerformed(ActionEvent evt) {
            java.util.Date tglsekarang = new java.util.Date();
            SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd MMMMMMMMM yyyy", Locale.getDefault());
            String tanggal = smpdtfmt.format(tglsekarang);
            String nol_jam = "", nol_menit = "",nol_detik = "";

            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();

            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";

            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);

            txtWaktu.setText(tanggal+" , "+jam+":"+menit+":"+detik+"");
            }
        };
        
    new Timer(1000, taskPerformer).start();
    }   
    
    private void HitungBiayaDewasa () {
        txtJumlahDewasa.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            int PersenDiskonDewasa  = 10,
                TotalBiayaDewasa    = 0,
                JumlahDewasa        = 0,
                TotalDiskonDewasa   = 0,
                BiayaDewasa         = 25000;
            
            @Override
            public void insertUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    if (txtJumlahDewasa.getText().equals("")) {}
                    else {
                        JumlahDewasa        = Integer.parseInt(txtJumlahDewasa.getText());
                        TotalBiayaDewasa    = BiayaDewasa * JumlahDewasa;
                        TotalDiskonDewasa   = TotalBiayaDewasa * PersenDiskonDewasa / 100;
                        txtBiayaDewasa.setText(String.valueOf(TotalBiayaDewasa));
                        txtDiskonDewasa.setText(String.valueOf(TotalDiskonDewasa));  
                    }
                } catch (Exception arg0) {}
                
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    if (txtJumlahDewasa.getText().equals("")) {}
                    else {
                        JumlahDewasa        = Integer.parseInt(txtJumlahDewasa.getText());
                        TotalBiayaDewasa    = BiayaDewasa * JumlahDewasa;
                        TotalDiskonDewasa   = TotalBiayaDewasa * (PersenDiskonDewasa / 100);
                        txtBiayaDewasa.setText(String.valueOf(TotalBiayaDewasa));
                        txtDiskonDewasa.setText(String.valueOf(TotalDiskonDewasa));
                    }
                } catch (Exception arg0) {}
                
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }
    
    private void HitungBiayaAnak() {
        txtJumlahAnak.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            int TotalBiayaAnak      = 0,
                JumlahAnak          = 0,
                BiayaAnak           = 15000;
            
            @Override
            public void insertUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    if (txtJumlahAnak.getText().equals("")) {}
                    else {
                        JumlahAnak          = Integer.parseInt(txtJumlahAnak.getText());
                        TotalBiayaAnak    = BiayaAnak * JumlahAnak;
                        txtBiayaAnak.setText(String.valueOf(TotalBiayaAnak));
                    }
                } catch (Exception arg0) {}
                
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    if (txtJumlahAnak.getText().equals("")) {}
                    else {
                        JumlahAnak          = Integer.parseInt(txtJumlahAnak.getText());
                        TotalBiayaAnak    = BiayaAnak * JumlahAnak;
                        txtBiayaAnak.setText(String.valueOf(TotalBiayaAnak));
                    }
                } catch (Exception arg0) {}
                
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }
    
    //METODE UNTUK CLEAR SEMUA DATA DALAM FORM
    public void HapusData(){
        txtId.setText("");
        txtJumlahDewasa.setText("");
        txtDiskonDewasa.setText("");
        txtBiayaDewasa.setText("");
        txtJumlahAnak.setText("");
        txtBiayaAnak.setText("");
        txtTotalBiaya.setText("");
    }
    
    public void HapusData2(){
        txtJumlahDewasa.setText("");
        txtDiskonDewasa.setText("");
        txtTotalBiaya.setText("");
        txtBiayaDewasa.setText("");
        txtJumlahAnak.setText("");
        txtBiayaAnak.setText("");
    }
    
    public void deletetable(){
        int row = ttable1.getRowCount();
        for (int i = 0; i<row ;i++){
            ttable1.removeRow(0);
        }
    }
    
    // METODE UNTUK MENAMPILKAN SEMUA DATA DARI DATABASE KE TABEL
    private void TampilAllData() {
        try{
            String[] judul = {"ID", "Dewasa", "Biaya Dewasa", "Anak-anak", "Biaya Anak", "Diskon", "Total Biaya"};
            ttable1 = new DefaultTableModel(null,judul);
            table1.setModel(ttable1);
            jScroll1.getViewport().add(table1);
            table1.setEnabled(true);
            koneksi ObjKoneksi1 = new koneksi();
            Connection con1 = ObjKoneksi1.OpenConnect();
            Statement st1 = con1.createStatement();
            String sql1 = "" +" SELECT tbl_datapengunjung.*" +" FROM tbl_datapengunjung ";
            ResultSet rs1 = st1.executeQuery(sql1);
            while(rs1.next()) {
                String id = rs1.getString("id");
                String jumlah_dewasa = rs1.getString("jumlah_dewasa");
                String biaya_dewasa = rs1.getString("biaya_dewasa");
                String jumlah_anak = rs1.getString("jumlah_anak");
                String biaya_anak = rs1.getString("biaya_anak");
                String diskon_dewasa = rs1.getString("diskon_dewasa");
                String total_biaya = rs1.getString("total_biaya");
                String[ ] data = {id, jumlah_dewasa, biaya_dewasa , jumlah_anak, biaya_anak, diskon_dewasa, total_biaya};
                ttable1.addRow(data);
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error : "+ ex);
        }
    }
    
    // METODE UNTUK MENAMPILKAN DATA KE TABEL
    public void Tampil1Data() {
        try{
            String[] judul = {"ID", "Dewasa", "Biaya Dewasa", "Anak-anak", "Biaya Anak", "Diskon", "Total Biaya"};
            ttable1 = new DefaultTableModel(null,judul);
            table1.setModel(ttable1);
            jScroll1.getViewport().add(table1);
            table1.setEnabled(true);
            koneksi ObjKoneksi1 = new koneksi();
            Connection con1 = ObjKoneksi1.OpenConnect();
            Statement st1 = con1.createStatement();
            String sql1 = "" +" SELECT tbl_datapengunjung.*" +" FROM tbl_datapengunjung " + " WHERE id ='" +txtId.getText() + "'" ;
            ResultSet rs1 = st1.executeQuery(sql1);
            while(rs1.next()) {
                String id = rs1.getString("id");
                String jumlah_dewasa = rs1.getString("jumlah_dewasa");
                String biaya_dewasa = rs1.getString("biaya_dewasa");
                String jumlah_anak = rs1.getString("jumlah_anak");
                String biaya_anak = rs1.getString("biaya_anak");
                String diskon_dewasa = rs1.getString("diskon_dewasa");
                String total_biaya = rs1.getString("total_biaya");
                String[ ] data = {id, jumlah_dewasa, biaya_dewasa , jumlah_anak, biaya_anak, diskon_dewasa, total_biaya};
                ttable1.addRow(data);
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error : "+ ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtJumlahDewasa = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        BtnSimpan = new javax.swing.JButton();
        BtnClear = new javax.swing.JButton();
        BtnHapus = new javax.swing.JButton();
        BtnEdit = new javax.swing.JButton();
        jScroll1 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        txtWaktu = new javax.swing.JTextField();
        txtJumlahAnak = new javax.swing.JTextField();
        txtTotalBiaya = new javax.swing.JTextField();
        txtDiskonDewasa = new javax.swing.JTextField();
        txtBiayaAnak = new javax.swing.JTextField();
        txtBiayaDewasa = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        BtnCari = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jPanel2.setBackground(new java.awt.Color(51, 51, 255));

        jLabel1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DATA PENGUNJUNG \"FESTIVAL MUSIK DARMAJAYA HORE\"");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        txtJumlahDewasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJumlahDewasaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel2.setText("JUMLAH DEWASA");

        jLabel3.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel3.setText("JUMLAH ANAK");

        jLabel4.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel4.setText("DISKON DEWASA");

        BtnSimpan.setText("SIMPAN");
        BtnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSimpanActionPerformed(evt);
            }
        });

        BtnClear.setText("CLEAR");
        BtnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnClearActionPerformed(evt);
            }
        });

        BtnHapus.setText("HAPUS");
        BtnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnHapusActionPerformed(evt);
            }
        });

        BtnEdit.setText("EDIT");
        BtnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEditActionPerformed(evt);
            }
        });

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Dewasa", "Biaya Dewasa", "Anak-anak", "Biaya Anak", "Diskon", "Total Biaya"
            }
        ));
        jScroll1.setViewportView(table1);

        jLabel5.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel5.setText("ID PENGUNJUNG");

        txtWaktu.setEditable(false);
        txtWaktu.setBackground(new java.awt.Color(204, 204, 255));
        txtWaktu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWaktuActionPerformed(evt);
            }
        });

        txtJumlahAnak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJumlahAnakActionPerformed(evt);
            }
        });

        txtTotalBiaya.setEditable(false);
        txtTotalBiaya.setBackground(new java.awt.Color(204, 204, 255));
        txtTotalBiaya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalBiayaActionPerformed(evt);
            }
        });

        txtDiskonDewasa.setEditable(false);
        txtDiskonDewasa.setBackground(new java.awt.Color(204, 204, 255));
        txtDiskonDewasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDiskonDewasaActionPerformed(evt);
            }
        });

        txtBiayaAnak.setEditable(false);
        txtBiayaAnak.setBackground(new java.awt.Color(204, 204, 255));
        txtBiayaAnak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBiayaAnakActionPerformed(evt);
            }
        });

        txtBiayaDewasa.setEditable(false);
        txtBiayaDewasa.setBackground(new java.awt.Color(204, 204, 255));
        txtBiayaDewasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBiayaDewasaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel6.setText("BIAYA DEWASA");

        jLabel7.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel7.setText("BIAYA ANAK");

        jLabel8.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        jLabel8.setText("TOTAL BIAYA");

        BtnCari.setText("CARI");
        BtnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCariActionPerformed(evt);
            }
        });

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScroll1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(BtnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64)
                                .addComponent(BtnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(txtWaktu)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addGap(12, 12, 12)
                                .addComponent(txtId)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BtnSimpan, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(BtnCari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtJumlahDewasa, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(txtJumlahAnak))
                            .addComponent(txtDiskonDewasa, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtBiayaDewasa)
                                    .addComponent(txtBiayaAnak)
                                    .addComponent(txtTotalBiaya, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(BtnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(50, 50, 50))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtJumlahDewasa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtJumlahAnak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtDiskonDewasa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBiayaDewasa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtBiayaAnak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtTotalBiaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(BtnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BtnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(BtnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BtnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtWaktu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnCari, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScroll1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtJumlahDewasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJumlahDewasaActionPerformed
        // TODO add your handling code here:
        int TotalBiaya = 0;
        if (txtBiayaDewasa.getText().equals("")) {}
        else if (txtBiayaAnak.getText().equals("")) {
            TotalBiaya  = Integer.parseInt(txtBiayaDewasa.getText()) - Integer.parseInt(txtDiskonDewasa.getText());
            txtTotalBiaya.setText(String.valueOf(TotalBiaya));
        }
        else {
            TotalBiaya  = Integer.parseInt(txtBiayaDewasa.getText()) + Integer.parseInt(txtBiayaAnak.getText()) - Integer.parseInt(txtDiskonDewasa.getText());
            txtTotalBiaya.setText(String.valueOf(TotalBiaya));
        }
    }//GEN-LAST:event_txtJumlahDewasaActionPerformed

        public void CariData(){
            if (txtId.getText().equals ("")) { }
            else {
                try {
                   koneksi ObHrgoneksi1 = new koneksi();
                   Connection con1 = ObHrgoneksi1.OpenConnect();
                   Statement st1 = con1.createStatement();
                   String sql1 = "" +
                   " SELECT tbl_datapengunjung.*" +
                   " FROM tbl_datapengunjung" +
                   " WHERE id ='" +txtId.getText() + "'" ;
                   ResultSet rs1 = st1.executeQuery(sql1);
                   
                   // Perulangan untuk memasukkan data dari database ke textbox
                    if(rs1.next()){
                        txtJumlahDewasa.setText(rs1.getString("jumlah_dewasa"));
                        txtBiayaDewasa.setText(rs1.getString("biaya_dewasa"));
                        txtBiayaAnak.setText(rs1.getString("biaya_anak"));
                        txtJumlahAnak.setText(rs1.getString("jumlah_anak"));
                        txtDiskonDewasa.setText(rs1.getString("diskon_dewasa"));
                        txtTotalBiaya.setText(rs1.getString("total_biaya"));

                        JOptionPane.showMessageDialog(this, "DATA ADA, SILAKAN EDIT / HAPUS !!!");
                    }
                    else{
                        JOptionPane.showMessageDialog(this, "DATA TIDAK DITEMUKAN !!!");
                        HapusData2(); //Untuk memanggil class HapusData
                    }
                Tampil1Data(); //Untuk memanggil class TampilAllData
                rs1.close();
                con1.close();
                }
                catch(SQLException e){}
        }
    }
        
        
    private void BtnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSimpanActionPerformed
     try{
        koneksi ObHrgoneksi1 = new koneksi();
        Connection con1 = ObHrgoneksi1.OpenConnect();
        Statement st1 = con1.createStatement();

        String sql1 = "INSERT INTO tbl_datapengunjung(jumlah_dewasa, jumlah_anak, biaya_dewasa, biaya_anak, diskon_dewasa, total_biaya) " + 
                "VALUES('"+txtJumlahDewasa.getText()+"',"
                + "'"+txtJumlahAnak.getText()+"',"
                + "'"+txtBiayaDewasa.getText()+"',"
                + "'"+txtBiayaAnak.getText()+"',"
                + "'"+txtDiskonDewasa.getText()+"',"
                + "'"+txtTotalBiaya.getText()+"')";
        int rows1 = st1.executeUpdate(sql1);
        JOptionPane.showMessageDialog(this, "Data Sukses Di Tambahkan!!!");
        TampilAllData();
        con1.close();
        } catch(SQLException e){
            
        }
    }//GEN-LAST:event_BtnSimpanActionPerformed

    private void BtnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnClearActionPerformed
        HapusData();
    }//GEN-LAST:event_BtnClearActionPerformed

    private void BtnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnHapusActionPerformed
        try{
            koneksi ObHrgoneksi1 = new koneksi();
            Connection con1 = ObHrgoneksi1.OpenConnect();
            Statement st1 = con1.createStatement();
            String sql1 = "DELETE FROM tbl_datapengunjung WHERE id='"+txtId.getText()+"'";

            int rows1 = st1.executeUpdate(sql1);
            if (rows1 == 1) {
            JOptionPane.showMessageDialog(this, "DATA BERHASIL DIHAPUS!!!");
            }
            con1.close();
            HapusData();
            TampilAllData() ;
        }
        catch(SQLException e) {}  
    }//GEN-LAST:event_BtnHapusActionPerformed

    private void txtWaktuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWaktuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWaktuActionPerformed

    private void BtnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEditActionPerformed
        try{
            koneksi ObHrgoneksi1 = new koneksi();
            Connection con1 = ObHrgoneksi1.OpenConnect();
            Statement st1 = con1.createStatement();
            
            String sql1 = "UPDATE tbl_datapengunjung SET "
                    + "jumlah_dewasa='"+txtJumlahDewasa.getText()+"',"
                    + "jumlah_anak='"+txtJumlahAnak.getText()+"',"
                    + "biaya_dewasa='"+txtBiayaDewasa.getText()+"',"
                    + "biaya_anak = '"+txtBiayaAnak.getText()+"',"
                    + "diskon_dewasa = '"+txtDiskonDewasa.getText()+"',"
                    + "total_biaya = '"+txtTotalBiaya.getText()+"' "
                    + "WHERE id='"+txtId.getText()+"'";
            
            int rows1 = st1.executeUpdate(sql1);
            if (rows1 == 1) {
                JOptionPane.showMessageDialog(this, "Sukses Di Edit !!!");
            }
            con1.close();
            TampilAllData();
        }
        catch(SQLException e) {}
    }//GEN-LAST:event_BtnEditActionPerformed

    private void txtJumlahAnakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJumlahAnakActionPerformed
        // TODO add your handling code here:
        int TotalBiaya = 0;
        if (txtBiayaAnak.getText().equals("")) {}
        else if (txtBiayaDewasa.getText().equals("")) {
            TotalBiaya  = Integer.parseInt(txtBiayaAnak.getText());
            txtTotalBiaya.setText(String.valueOf(TotalBiaya));
        }
        else {
            TotalBiaya  = Integer.parseInt(txtBiayaDewasa.getText()) + Integer.parseInt(txtBiayaAnak.getText()) - Integer.parseInt(txtDiskonDewasa.getText());
            txtTotalBiaya.setText(String.valueOf(TotalBiaya));
        }
    }//GEN-LAST:event_txtJumlahAnakActionPerformed

    private void txtTotalBiayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalBiayaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalBiayaActionPerformed

    private void txtDiskonDewasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiskonDewasaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDiskonDewasaActionPerformed

    private void txtBiayaAnakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBiayaAnakActionPerformed

    }//GEN-LAST:event_txtBiayaAnakActionPerformed

    private void txtBiayaDewasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBiayaDewasaActionPerformed

    }//GEN-LAST:event_txtBiayaDewasaActionPerformed

    private void BtnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCariActionPerformed
        // TODO add your handling code here:
        CariData();
    }//GEN-LAST:event_BtnCariActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data_pengunjung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data_pengunjung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data_pengunjung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data_pengunjung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new data_pengunjung().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCari;
    private javax.swing.JButton BtnClear;
    private javax.swing.JButton BtnEdit;
    private javax.swing.JButton BtnHapus;
    private javax.swing.JButton BtnSimpan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScroll1;
    private javax.swing.JTable table1;
    private javax.swing.JTextField txtBiayaAnak;
    private javax.swing.JTextField txtBiayaDewasa;
    private javax.swing.JTextField txtDiskonDewasa;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtJumlahAnak;
    private javax.swing.JTextField txtJumlahDewasa;
    private javax.swing.JTextField txtTotalBiaya;
    private javax.swing.JTextField txtWaktu;
    // End of variables declaration//GEN-END:variables
}
