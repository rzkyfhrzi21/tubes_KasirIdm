/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app_datapengunjung;

/**
 *
 * @author ASUS
 */
import java.sql.*;

public class koneksi {
    public Connection OpenConnect() throws SQLException{
    Connection con1 = null;
    try {
        Class.forName("com.mysql.jdbc.Driver");
        con1=DriverManager.getConnection("jdbc:mysql://localhost/app_datapengunjung","root","");
        return con1;
        } 
        catch (SQLException se) {
        System.out.println("Perintah SQL Salah!!!");
        return null;
        } 
        catch (Exception ex) {
        System.out.println("Driver Tidak Terhubung!!!");
        return null;
        }
    }
}
