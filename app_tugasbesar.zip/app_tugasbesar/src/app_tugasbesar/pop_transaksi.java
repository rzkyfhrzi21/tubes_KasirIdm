/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app_tugasbesar;

/**
 *
 * @author LENOVO
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.text.NumberFormat;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class pop_transaksi extends javax.swing.JFrame {
    
    
    private static final String CHARACTERS  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int ID_LENGTH      = 6;
    private static final Random random      = new Random();
      
    
    NumberFormat nf = NumberFormat.getNumberInstance(new Locale("in", "ID"));
    
    public pop_transaksi() {
        initComponents();
        TampilJam();
        TampilTanggal();
        TampilNoTransaksi();
        KodeBarang();
        Total();
//        TotalBersih();
        TotalTunai();
    }
    
    public void TampilJam(){
        ActionListener taskPerformer = new ActionListener() {

        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";

            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();

            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";

            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);

            txtWaktu.setText(jam+":"+menit+":"+detik+"");
            }
        };
        
    new Timer(1000, taskPerformer).start();
    }   

    public void TampilTanggal() {
        java.util.Date tglsekarang = new java.util.Date();
        SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd MMMMMMMMM yyyy", Locale.getDefault());
        String tanggal = smpdtfmt.format(tglsekarang);
        txtTanggal.setText(tanggal);
    }
    
    String noTransaksi = generateRandomId(ID_LENGTH);
    
    public void TampilNoTransaksi () {
        txtNoTransaksi.setText(noTransaksi);
    }
    
    private void Total() {
        txtJumlahBeli.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    int hasil = 0;
                        if (txtJumlahBeli.getText().equals("")){
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 0;
                        } else {
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 
                                    Integer.parseInt(txtJumlahBeli.getText());
                        }
                        txtSubTotal.setText(nf.format(hasil));
                } catch (Exception e) {
                }
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                try {
                    int hasil = 0;
                        if (txtJumlahBeli.getText().equals("")){
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 0;
                        } else {
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 
                                    Integer.parseInt(txtJumlahBeli.getText());
                        }
                        txtSubTotal.setText(nf.format(hasil));
                } catch (Exception e) {
                }
            }

            @Override
            public void changedUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                            try {
                    int hasil = 0;
                        if (txtJumlahBeli.getText().equals("")){
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 0;
                        } else {
                            hasil = Integer.parseInt(txtHargaBarang.getText().replace(".", "")) * 
                                    Integer.parseInt(txtJumlahBeli.getText());
                        }
                        txtSubTotal.setText(nf.format(hasil));
                } catch (Exception e) {
                }
            }
        });
    }
    
    private void TotalBersih() {
        txtTotalHarga.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                
                // pajak ppn 10%
                int hasil_ppn   = 0;
                hasil_ppn       = Integer.parseInt(txtTotalHarga.getText().replace(".", "")) * 10 / 100;
                txtPPN.setText(nf.format(hasil_ppn));

                // total bersih semua
                int total_bersih = 0;
                total_bersih     = hasil_ppn + Integer.parseInt(txtTotalHarga.getText().replace(".",""));
                txtTotalBersih.setText(nf.format(total_bersih)); 

            }

            @Override
            public void removeUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                
                // pajak ppn 10%
                int hasil_ppn   = 0;
                hasil_ppn       = Integer.parseInt(txtTotalHarga.getText().replace(".", "")) * 10 / 100;
                txtPPN.setText(nf.format(hasil_ppn));

                // total bersih semua
                int total_bersih = 0;
                total_bersih     = hasil_ppn + Integer.parseInt(txtTotalHarga.getText().replace(".",""));
                txtTotalBersih.setText(nf.format(total_bersih));
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

            }
        });
    }
    
     private void TotalTunai() {
        txtTunai.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                    
                // bayar tunai + kembalian
                try {
                    int kembalian, total, tunai;
                    if (txtTunai.getText().equals("")){
                    } else {
                        total           = Integer.parseInt(txtTotalBersih.getText().replace(".",""));
                        tunai           = Integer.parseInt(txtTunai.getText().replace(".",""));
                        kembalian       = tunai - total;
                        txtKembalian.setText(nf.format(kembalian));
                    }
                } catch (Exception e) {
                }      
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                    
                // bayar tunai + kembalian
                try {
                    int kembalian, total, tunai;
                    if (txtTunai.getText().equals("")){
                    } else {
                        total           = Integer.parseInt(txtTotalBersih.getText().replace(".",""));
                        tunai           = Integer.parseInt(txtTunai.getText().replace(".",""));
                        kembalian       = tunai - total;
                        txtKembalian.setText(nf.format(kembalian));
                    }
                } catch (Exception e) {
                } 
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
 
            }
        });
    }
            
    private void KodeBarang(){
        txtKodeBarang.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                String kodeBarang;
                kodeBarang  = (String) txtKodeBarang.getText();
                try{                
                    koneksi ObjKoneksi1 = new koneksi();
                    Connection con1 = ObjKoneksi1.OpenConnect();
                    Statement st1 = con1.createStatement();
                    String sql1 = "" +" SELECT tbl_barang.*" +" FROM tbl_barang " + " WHERE kode_barang ='" +txtKodeBarang.getText().toUpperCase() + "'" ;
                    ResultSet rs1 = st1.executeQuery(sql1);
                    while(rs1.next()) {
                        txtNamaBarang.setText(rs1.getString("nama_barang"));
                        txtHargaBarang.setText(rs1.getString("harga_barang"));
                        txtJumlahBeli.grabFocus();
                        }
                }
                catch(Exception ex) {
//                    JOptionPane.showMessageDialog(this, "Error : "+ ex);
                }
            }
            

            @Override
            public void removeUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                String kodeBarang;
                kodeBarang  = (String) txtKodeBarang.getText();
                try{                
                    koneksi ObjKoneksi1 = new koneksi();
                    Connection con1 = ObjKoneksi1.OpenConnect();
                    Statement st1 = con1.createStatement();
                    String sql1 = "" +" SELECT tbl_barang.*" +" FROM tbl_barang " + " WHERE kode_barang ='" +txtKodeBarang.getText().toUpperCase() + "'" ;
                    ResultSet rs1 = st1.executeQuery(sql1);
                    while(rs1.next()) {
                        txtNamaBarang.setText(rs1.getString("nama_barang"));
                        txtHargaBarang.setText(rs1.getString("harga_barang"));
                        txtJumlahBeli.grabFocus();
                        }
                }
                catch(Exception ex) {
//                    JOptionPane.showMessageDialog(this, "Error : "+ ex);
                }
            }

            @Override
            public void changedUpdate(DocumentEvent arg0) {
//                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNoTransaksi = new javax.swing.JTextField();
        txtNamaCustomer = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtWaktu = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtHargaBarang = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtJumlahBeli = new javax.swing.JTextField();
        jScrollPane = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        txtPPN = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtTunai = new javax.swing.JTextField();
        btnSimpanTransaksi = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtTanggal = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtNamaBarang = new javax.swing.JTextField();
        txtKodeBarang = new javax.swing.JTextField();
        txtTotalBersih = new javax.swing.JTextField();
        txtKembalian = new javax.swing.JTextField();
        txtTotalHarga = new javax.swing.JTextField();
        txtSubTotal = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        jRadioButton1.setText("jRadioButton1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("KASIR");

        jLabel2.setText("KODE TRANSAKSI");

        jLabel3.setText("NAMA CUSTOMER");

        txtNoTransaksi.setEditable(false);
        txtNoTransaksi.setBackground(new java.awt.Color(204, 204, 255));
        txtNoTransaksi.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNoTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNoTransaksiActionPerformed(evt);
            }
        });

        txtNamaCustomer.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNamaCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaCustomerActionPerformed(evt);
            }
        });

        jLabel4.setText("TANGGAL");

        txtWaktu.setEditable(false);
        txtWaktu.setBackground(new java.awt.Color(204, 204, 255));
        txtWaktu.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel5.setText("KODE BARANG");

        jLabel6.setText("NAMA BARANG");

        txtHargaBarang.setEditable(false);
        txtHargaBarang.setBackground(new java.awt.Color(204, 204, 255));
        txtHargaBarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtHargaBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHargaBarangActionPerformed(evt);
            }
        });

        jLabel7.setText("HARGA BARANG");

        jLabel8.setText("JUMLAH BELI");

        txtJumlahBeli.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtJumlahBeli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJumlahBeliActionPerformed(evt);
            }
        });

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NO", "KODE BARANG", "NAMA BARANG", "HARGA", "JUMLAH", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane.setViewportView(table1);

        txtPPN.setEditable(false);
        txtPPN.setBackground(new java.awt.Color(204, 204, 255));
        txtPPN.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtPPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPPNActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("TOTAL");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("TUNAI");

        txtTunai.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtTunai.setToolTipText("Rupiah");
        txtTunai.setMinimumSize(new java.awt.Dimension(65, 25));
        txtTunai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTunaiActionPerformed(evt);
            }
        });

        btnSimpanTransaksi.setBackground(new java.awt.Color(153, 204, 255));
        btnSimpanTransaksi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSimpanTransaksi.setForeground(new java.awt.Color(255, 255, 255));
        btnSimpanTransaksi.setText("SIMPAN");
        btnSimpanTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanTransaksiActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TRANSAKSI KASIR");

        jButton1.setText("Menu");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(307, 307, 307)
                .addComponent(jLabel1)
                .addContainerGap(324, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 39, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(30, 30, 30))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClear.setText("REFRESH");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel9.setText("WAKTU");

        txtTanggal.setEditable(false);
        txtTanggal.setBackground(new java.awt.Color(204, 204, 255));
        txtTanggal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTanggal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTanggalActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("KEMBALIAN");

        txtNamaBarang.setEditable(false);
        txtNamaBarang.setBackground(new java.awt.Color(204, 204, 255));
        txtNamaBarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNamaBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaBarangActionPerformed(evt);
            }
        });

        txtKodeBarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtKodeBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKodeBarangActionPerformed(evt);
            }
        });

        txtTotalBersih.setEditable(false);
        txtTotalBersih.setBackground(new java.awt.Color(204, 204, 255));
        txtTotalBersih.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        txtTotalBersih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalBersihActionPerformed(evt);
            }
        });

        txtKembalian.setEditable(false);
        txtKembalian.setBackground(new java.awt.Color(204, 204, 255));
        txtKembalian.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtKembalian.setToolTipText("Rupiah");
        txtKembalian.setMinimumSize(new java.awt.Dimension(65, 25));
        txtKembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKembalianActionPerformed(evt);
            }
        });

        txtTotalHarga.setEditable(false);
        txtTotalHarga.setBackground(new java.awt.Color(204, 204, 255));
        txtTotalHarga.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtTotalHarga.setToolTipText("Rupiah");
        txtTotalHarga.setMinimumSize(new java.awt.Dimension(65, 25));
        txtTotalHarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalHargaActionPerformed(evt);
            }
        });

        txtSubTotal.setEditable(false);
        txtSubTotal.setBackground(new java.awt.Color(204, 204, 255));
        txtSubTotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSubTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSubTotalActionPerformed(evt);
            }
        });

        jLabel17.setText("SUB TOTAL");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("PPN (10%)");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setText("JUMLAH");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(txtKodeBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtNamaCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(txtWaktu, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNamaBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtNoTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addComponent(txtHargaBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(28, 28, 28)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addGap(0, 82, Short.MAX_VALUE))
                                            .addComponent(txtJumlahBeli))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel17)
                                            .addComponent(txtSubTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addComponent(jScrollPane)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel16)
                            .addComponent(jLabel18))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTotalHarga, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                            .addComponent(txtPPN))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(18, 18, 18)
                                .addComponent(txtKembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(txtTunai, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnSimpanTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtTotalBersih))))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNoTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNamaCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtWaktu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtHargaBarang)
                        .addComponent(txtNamaBarang)
                        .addComponent(txtKodeBarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtSubTotal)
                        .addComponent(txtJumlahBeli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSimpanTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(txtTotalBersih, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTotalHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtTunai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtKembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private static String generateRandomId(int length) {
        StringBuilder id = new StringBuilder(length);
        for (int i = 0; i<length; i++){
            id.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }
        return id.toString();
    }
    
    private void txtNamaCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaCustomerActionPerformed

    
    private void txtTunaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTunaiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTunaiActionPerformed

    private void txtJumlahBeliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJumlahBeliActionPerformed
        // TODO add your handling code here:
        if (txtJumlahBeli.getText().equals("")) {
            
        } else {
            DefaultTableModel model = (DefaultTableModel) table1.getModel();
            
            Object obj []   = new Object[6];
            obj [1]         = txtKodeBarang.getText().toUpperCase(); 
            obj [2]         = txtNamaBarang.getText();
            obj [3]         = txtHargaBarang.getText().replace(".", "");
            obj [4]         = txtJumlahBeli.getText();
            obj [5]         = txtSubTotal.getText().replace(".", "");
            
            model.addRow(obj);
            
            int baris    = model.getRowCount();
            for (int i = 0; i < baris; i++){
                String no = String.valueOf(i + 1);
                model.setValueAt(no+".", i, 0);
            }
            table1.setRowHeight(30);
//            txtTotalBarang.setText(String.valueOf(baris));
            
            jmlTotalHarga();
            BersihInputan();
        }
    }//GEN-LAST:event_txtJumlahBeliActionPerformed

    private void txtPPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPPNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPPNActionPerformed

    private void btnSimpanTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanTransaksiActionPerformed
        // TODO add your handling code here:
        if (txtNamaCustomer.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "ISI NAMA ANDA TERLEBIH DAHULU !!!");
        } else if (txtTotalBersih.getText().equals("")){
            JOptionPane.showMessageDialog(this, "SILAHKAN PILIH BELANJAAN ANDA !!!");
        } else if (txtTunai.getText().equals("")){
            JOptionPane.showMessageDialog(this, "SILAHKAN BAYAR !!!");
        } else {
                try{
                    koneksi ObHrgoneksi1    = new koneksi();
                    Connection con1         = ObHrgoneksi1.OpenConnect();
                    Statement st1           = (Statement) con1.createStatement();
                    String sql1             = "INSERT INTO tbl_transaksi(no_transaksi, nama_customer, tanggal, waktu, total_harga, tunai, kembalian, ppn, total_bersih)" +
                    "values('"+txtNoTransaksi.getText()+
                    "','"+txtNamaCustomer.getText().toUpperCase()+
                    "','"+txtTanggal.getText()+
                    "','"+txtWaktu.getText()+
                    "','"+txtTotalHarga.getText().replace(".", "")+
                    "','"+txtTunai.getText().replace(".", "")+
                    "','"+txtKembalian.getText().replace(".", "")+
                    "','"+txtPPN.getText().replace(".", "")+
        //            "','"+cb_jk.getSelectedItem().toString()+
                    "','"+txtTotalBersih.getText().replace(".", "")+"')";
                    int rows1 = st1.executeUpdate(sql1);
                    if (rows1 == 1) {
                        JOptionPane.showMessageDialog(this, "Transaksi Berhasil, Belanja puas harga pas :)");
                        con1.close();
                        Refresh();
                    } 
                }
                catch(SQLException e) {
                }
        }

    }//GEN-LAST:event_btnSimpanTransaksiActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        Refresh();
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtTanggalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTanggalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTanggalActionPerformed

    private void txtNoTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNoTransaksiActionPerformed

    }//GEN-LAST:event_txtNoTransaksiActionPerformed

    private void txtHargaBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHargaBarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHargaBarangActionPerformed

    private void txtNamaBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaBarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaBarangActionPerformed

    private void txtKodeBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKodeBarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtKodeBarangActionPerformed

    private void txtTotalBersihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalBersihActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalBersihActionPerformed

    private void txtKembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtKembalianActionPerformed

    private void txtTotalHargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalHargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalHargaActionPerformed

    private void txtSubTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSubTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSubTotalActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new hal_datatransaksi().show();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pop_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pop_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pop_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pop_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pop_transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSimpanTransaksi;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable table1;
    private javax.swing.JTextField txtHargaBarang;
    private javax.swing.JTextField txtJumlahBeli;
    private javax.swing.JTextField txtKembalian;
    private javax.swing.JTextField txtKodeBarang;
    private javax.swing.JTextField txtNamaBarang;
    private javax.swing.JTextField txtNamaCustomer;
    private javax.swing.JTextField txtNoTransaksi;
    private javax.swing.JTextField txtPPN;
    private javax.swing.JTextField txtSubTotal;
    private javax.swing.JTextField txtTanggal;
    private javax.swing.JTextField txtTotalBersih;
    private javax.swing.JTextField txtTotalHarga;
    private javax.swing.JTextField txtTunai;
    private javax.swing.JTextField txtWaktu;
    // End of variables declaration//GEN-END:variables

    private void jmlTotalHarga() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        int sub_total = 0;
        for (int a = 0; a < table1.getRowCount(); a++) {
            sub_total += Integer.parseInt((String) 
                    table1.getValueAt(a, 5).toString().replace(".", ""));
        }
        txtTotalHarga.setText(nf.format(sub_total));
        
        // pajak ppn 10%
        int hasil_ppn   = 0;
        hasil_ppn       = Integer.parseInt(txtTotalHarga.getText().replace(".", "")) * 10 / 100;
        txtPPN.setText(nf.format(hasil_ppn));
        
        // total bersih semua
        int total_bersih = 0;
        total_bersih     = hasil_ppn + Integer.parseInt(txtTotalHarga.getText().replace(".",""));
        txtTotalBersih.setText(nf.format(total_bersih));
        
    }
    
    private void Refresh() {
        new pop_transaksi().show();
        this.dispose();
    }

    private void BersihInputan() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        txtKodeBarang.setText("");
        txtNamaBarang.setText("");
        txtHargaBarang.setText("");
        txtJumlahBeli.setText("");
        txtSubTotal.setText("");
        txtKodeBarang.grabFocus();
    }

//    private void BersihkanData() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//        DefaultTableModel model = (DefaultTableModel) table1.getModel();
//        model.setRowCount(0);
        
//        txtNamaCustomer.setText("");
//        txtKodeBarang.setText("");
//        txtNamaBarang.setText("");
//        txtHargaBarang.setText("");
//        txtJumlahBeli.setText("");
//        txtSubTotal.setText("");
//        txtTotalHarga.setText("");
//        txtPPN.setText("");
//        txtTotalBersih.setText("");
//        txtTunai.setText("");
//        txtKembalian.setText("");
//            
//    }
}
